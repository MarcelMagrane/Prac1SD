def main(text):
    
    text = text.replace(',', '')
    text = text.replace('.', '')
    
    text = text.split()
    
    d = dict()
    
    for word in text:
        if word in d:
            d[word] += 1
        else:
            d[word] = 1
    
    return d

from cos_backend import COS_Backend
import wordcount


def main(args):
    conf = args.get("credentials")
    text = args.get("text")
    order = args.get("order")
    cos = COS_Backend(conf)
    print(wordcount)
    result = wordcount.main(text)
    
    f = open("wc{0}.txt".format(order), "w")
    f.write(str(result))
    f = open("wc{0}.txt".format(order), 'r')
    cos.put_object('sdprac1', "wc{0}.txt".format(order), f.read())
        
    return {}
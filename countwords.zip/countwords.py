def main(text):
    
    text = text.replace(',', '')
    text = text.replace('.', '')
    
    number = len(text.split())
    
    return number
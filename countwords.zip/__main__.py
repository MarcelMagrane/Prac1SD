from cos_backend import COS_Backend
import countwords


def main(args):
    conf = args.get("credentials")
    text = args.get("text")
    cos = COS_Backend(conf)
    
    text = cos.get_object('sdprac1', text)
    text = text.decode('utf-8')
    result = countwords.main(text)
    
    f = open("countw.txt", "w")
    f.write(str(result))
    f = open("countw.txt", 'r')
    cos.put_object('sdprac1', "countw.txt", f.read())
        
    return {}